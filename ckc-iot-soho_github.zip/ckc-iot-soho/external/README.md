# External evaluation

An independent check on the original CICIoT2023 release, using capture-file-disjoint cross-validation
(no capture file contributes records to both training and test sets).

1. `build_external_sample.py path/to/ciciot2023.parquet` rebuilds the exact 747,267-record sample (305 capture files)
   from the cleaned full release, using the row numbers in `external_sample_index.csv.gz`.
   The script checks that the input has 46,776,697 rows.
2. `external_evaluation.py` trains LightGBM (four feature sets: all, without IAT, without TTL, without both),
   XGBoost and Random Forest, and compares a random record-level split with 4 capture-file-disjoint folds.
   Output: `results/external/e1_external.json`.

The six categories (Benign, DDoS, DoS, Mirai, Recon, Web) come from the `category` column of the cleaned release.
